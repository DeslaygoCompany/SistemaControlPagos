<?php $__env->startSection('botonNavUsuarios'); ?>
<?php echo e('active'); ?>

<?php $__env->stopSection(); ?>


<!--Inicio el contenido de deudores-->
<?php $__env->startSection('contenido'); ?>
    <div class="container contenido">
        <div class="row">
           <div class="col-12 encabezado">
               <h3>SECCIÓN DE USUARIOS</h3>
           </div>
       </div>
        <div class="row">
            <div class="col-md-4">
                <button class="btn btn-agregar" type="button" data-toggle="collapse" data-target="#collapseAgregar" aria-expanded="false" aria-controls="collapseExample"><i class="fa fa-plus-circle"></i> Agregar usuario</button>
                <a href="/exportarUsuarios" class="btn btn-agregar ml-2"><i class="fa fa-file-excel-o"></i> Exportar</a>
            </div>
        </div>
        <div class="row mt-2 mb-2">
            <div class="col-md-12">
               <?php echo $__env->make('modulos.usuarios.collapse-agregar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <div class="row">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">Nombre de usuario</th>
                        <th scope="col">Email</th>
                        <th scope="col">Contraseña</th>
                        <th scope="col">Rol</th>
                        <th escope="col">Eliminar</th>
                    </tr>
                </thead>
                <tbody>
                   <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                   	<td><?php echo e($u->username); ?></td>
                   	<td><?php echo e($u->email); ?></td>
                   	<td><?php echo e($u->password); ?></td>
                   	<td><?php echo e($u->rol); ?></td>
                   	<td><button class="btn btn-eliminar" data-toggle="modal" data-target="#modalEliminarUser" data-id="<?php echo e($u->id); ?>" data-username="<?php echo e($u->username); ?>"><i class="fa fa-trash-o"></i></button></td>
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tbody>
            </table>
        </div>
        <div class="row mt-2 mb-2">
            
        </div>
        
    </div>
    
<?php echo $__env->make('modulos.usuarios.modal-eliminar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<!--fin del contenido de deudores-->
<?php echo $__env->make('main-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>