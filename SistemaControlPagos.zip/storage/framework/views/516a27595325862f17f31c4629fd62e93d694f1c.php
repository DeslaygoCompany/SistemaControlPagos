<?php $__env->startSection('botonNavPagos'); ?>
<?php echo e('active'); ?>

<?php $__env->stopSection(); ?>

<!--Inicio el contenido de deudores-->
<?php $__env->startSection('contenido'); ?>
    <div class="container contenido">
       <div class="row">
           <div class="col-12 encabezado">
               <h3>SECCIÓN DE PAGOS</h3>
           </div>
       </div>
        <div class="row">
            <div class="col-md-4">
                <button class="btn btn-agregar" type="button" data-toggle="collapse" data-target="#collapseAgregar" aria-expanded="false" aria-controls="collapseExample"><i class="fa fa-plus-circle"></i> Agregar Pago</button>
                <a href="/exportarFacturas" class="btn btn-agregar ml-2"><i class="fa fa-file-excel-o"></i> Exportar</a>
            </div>
        </div>
        <div class="row mt-2 mb-2">
            <div class="col-md-12">
               <?php echo $__env->make('modulos.facturas.collapse-agregar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <div class="row">
            <table class="table table-bordered" id="tablaFacturas">
                <thead>
                    <tr>
                        <th scope="col">Folio</th>
                        <th scope="col">Estado de la factura</th>
                        <th scope="col">Nombre del deudor</th>
                        <th scope="col">No. pago</th>
                        <th scope="col">Fecha de pago</th>
                        <th scope="col">Método de pago</th>
                        <th scope="col">Cantidad</th>
                        <th scope="col">Editar</th>
                        <th scope="col">Cambiar estado</th>
                        <th scope="col">Eliminar</th>
                        <th scope="col">Ver factura</th>
                    </tr>
                </thead>
                <tbody>
                   <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                       <td><?php echo e($factura->folio); ?></td>
                       <?php if($factura->estado == "Realizado"): ?>
                       <td class="estado"><div class="estado-realizado">1</div></td>
                       <?php elseif($factura->estado == "Pendiente"): ?>
                       <td class="estado"><div class="estado-pendiente">0</div></td>
                       <?php endif; ?>
                       <td><?php echo e($factura->deudor->nombre); ?> <?php echo e($factura->deudor->apellidos); ?></td>
                       <td><?php echo e($factura->no_pago); ?></td>
                       <td><?php echo e(date('d-m-y',strtotime($factura->fecha_pago))); ?></td>
                       <td><?php echo e($factura->detalle_factura->metodo_pago); ?></td>
                       <td><?php echo e($factura->detalle_factura->cantidad); ?></td>
                       <td><button class="btn btn-cambiar" data-toggle="modal" data-target="#modalModificar" data-id="<?php echo e($factura->id); ?>" data-estado="<?php echo e($factura->estado); ?>" data-fecha="<?php echo e($factura->fecha_pago); ?>" data-metodo="<?php echo e($factura->detalle_factura->metodo_pago); ?>" data-banco="<?php echo e($factura->detalle_factura->banco); ?>" data-cantidad="<?php echo e($factura->detalle_factura->cantidad); ?>" data-idfact="<?php echo e($factura->detalle_factura->id); ?>"><i class="fa fa-pencil-square-o"></i></button></td>
                       <td><button class="btn btn-cambiar" data-toggle="modal" data-target="#modalCambiar" data-id="<?php echo e($factura->id); ?>" data-estado="<?php echo e($factura->estado); ?>"><i class="fa fa-toggle-on"></i></button></td>
                       <td><button class="btn btn-eliminar" data-toggle="modal" data-target="#modalEliminarFactura" data-id="<?php echo e($factura->id); ?>" data-folio="<?php echo e($factura->folio); ?>"><i class="fa fa-trash-o"></i></button></td>
                        <td><a href="verFactura/<?php echo e($factura->id); ?>" class="btn btn-detalles" ><i class="fa fa-file-pdf-o"></i></a></td>
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="row mt-2 mb-2">
            
        </div>
        
    </div>
<!--Inicio de modales-->
<?php echo $__env->make('modulos.facturas.modal-eliminar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('modulos.facturas.modal-cambiar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('modulos.facturas.modal-modificar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Fin de modales-->
<?php $__env->stopSection(); ?>
<!--fin del contenido de deudores-->
<?php echo $__env->make('main-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>