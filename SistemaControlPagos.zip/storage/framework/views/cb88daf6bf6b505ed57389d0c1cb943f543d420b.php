<?php $__env->startSection('botonNavHistorial'); ?>
<?php echo e('active'); ?>

<?php $__env->stopSection(); ?>


<!--Inicio el contenido de perfil deudor-->
<?php $__env->startSection('contenido'); ?>
    <div class="container contenido">
  <div class="card mt-2">
  <div class="card-header">
    <h3 id="title-info"><strong>Historial de pagos</strong></h3>
  </div>
  <div class="card-body">
   <table class="table table-bordered" id="tablaFacturas">
                <thead>
                    <tr>
                        <th scope="col">Folio</th>
                        <th scope="col">Estado de la factura</th>
                        <th scope="col">Fecha de expedición</th>
                        <th scope="col">Número de pago</th>
                        <th scope="col">Fecha de pago</th>
                        <th scope="col">Método de pago</th>
                        <th scope="col">Cantidad</th>
                        <th scope="col">Total</th>
                        <th scope="col">Descargar factura</th>
                    </tr>
                </thead>
                <tbody>
                   <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php if($factura->id_deudor == Auth::user()->id_deudor): ?>
                   <tr>
                       <td><?php echo e($factura->folio); ?></td>
                       <?php if($factura->estado == "Realizado"): ?>
                       <td class="estado"><div class="estado-realizado">1</div></td>
                       <?php elseif($factura->estado == "Pendiente"): ?>
                       <td class="estado"><div class="estado-pendiente">0</div></td>
                       <?php endif; ?>
                       <td><?php echo e($factura->fecha_expedicion); ?></td>
                       <td><?php echo e($factura->no_pago); ?></td>
                       <td><?php echo e($factura->fecha_pago); ?></td>
                       <td><?php echo e($factura->detalle_factura->metodo_pago); ?></td>
                       <td><?php echo e($factura->detalle_factura->cantidad); ?></td>
                       <td><?php echo e($factura->deudor->deuda->total); ?></td>
                       <td><a href="/descargarFactura/<?php echo e($factura->id); ?>" class="btn btn-detalles" ><i class="fa fa-download"></i></a></td>
                   </tr>
                   <?php endif; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
  
  </div>
  </div>
    

<?php $__env->stopSection(); ?>
<!--fin del contenido de perfil deudor-->
<?php echo $__env->make('main-deudor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>